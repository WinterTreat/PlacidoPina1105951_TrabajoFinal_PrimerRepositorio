using OutputProgram;
using InputProgram;
using PaginationProgram;
namespace PaginationNugget.Tests;

[TestClass]
public class ValidInputs
{
    [TestMethod]
    public void TestMethod_1_1()
    {

        Pagination pagination = new Pagination();
        Input currentPage = new Input(1);
        Input totalPages = new Input(1);
        Output output = pagination.Result(currentPage, totalPages);

        Assert.AreEqual("(1)", output.getResult());
    }

    [TestMethod]
    public void TestMethod_1_2()
    {

        Pagination pagination = new Pagination();
        Input currentPage = new Input(1);
        Input totalPages = new Input(2);
        Output output = pagination.Result(currentPage, totalPages);

        Assert.AreEqual("(1) 2", output.getResult());
    }

    [TestMethod]
    public void TestMethod_1_3()
    {

        Pagination pagination = new Pagination();
        Input currentPage = new Input(1);
        Input totalPages = new Input(3);
        Output output = pagination.Result(currentPage, totalPages);

        Assert.AreEqual("(1) 2 3", output.getResult());
    }

    [TestMethod]
    public void TestMethod_1_4()
    {

        Pagination pagination = new Pagination();
        Input currentPage = new Input(1);
        Input totalPages = new Input(4);
        Output output = pagination.Result(currentPage, totalPages);

        Assert.AreEqual("(1) 2 3 4", output.getResult());
    }

    [TestMethod]
    public void TestMethod_1_5()
    {

        Pagination pagination = new Pagination();
        Input currentPage = new Input(1);
        Input totalPages = new Input(5);
        Output output = pagination.Result(currentPage, totalPages);

        Assert.AreEqual("(1) 2 3 4 5", output.getResult());
    }

    [TestMethod]
    public void TestMethod_1_6()
    {

        Pagination pagination = new Pagination();
        Input currentPage = new Input(1);
        Input totalPages = new Input(6);
        Output output = pagination.Result(currentPage, totalPages);

        Assert.AreEqual("(1) 2 3 4 5 6", output.getResult());
    }

    [TestMethod]
    public void TestMethod_1_7()
    {

        Pagination pagination = new Pagination();
        Input currentPage = new Input(1);
        Input totalPages = new Input(7);
        Output output = pagination.Result(currentPage, totalPages);

        Assert.AreEqual("(1) 2 3 4 5 6 7", output.getResult());
    }

    [TestMethod]
    public void TestMethod_1_8()
    {

        Pagination pagination = new Pagination();
        Input currentPage = new Input(1);
        Input totalPages = new Input(8);
        Output output = pagination.Result(currentPage, totalPages);

        Assert.AreEqual("(1) 2 3 4 5 ... 8", output.getResult());
    }

    [TestMethod]
    public void TestMethod_1_9()
    {

        Pagination pagination = new Pagination();
        Input currentPage = new Input(1);
        Input totalPages = new Input(9);
        Output output = pagination.Result(currentPage, totalPages);

        Assert.AreEqual("(1) 2 3 4 5 ... 9", output.getResult());
    }

    [TestMethod]
    public void TestMethod_1_10()
    {

        Pagination pagination = new Pagination();
        Input currentPage = new Input(1);
        Input totalPages = new Input(10);
        Output output = pagination.Result(currentPage, totalPages);

        Assert.AreEqual("(1) 2 3 4 5 ... 10", output.getResult());
    }

    [TestMethod]
    public void TestMethod_5_10()
    {

        Pagination pagination = new Pagination();
        Input currentPage = new Input(5);
        Input totalPages = new Input(10);
        Output output = pagination.Result(currentPage, totalPages);

        Assert.AreEqual("1 ... 4 (5) 6 ... 10", output.getResult());
    }

    [TestMethod]
    public void TestMethod_10_10()
    {

        Pagination pagination = new Pagination();
        Input currentPage = new Input(10);
        Input totalPages = new Input(10);
        Output output = pagination.Result(currentPage, totalPages);

        Assert.AreEqual("1 ... 6 7 8 9 (10)", output.getResult());
    }
}