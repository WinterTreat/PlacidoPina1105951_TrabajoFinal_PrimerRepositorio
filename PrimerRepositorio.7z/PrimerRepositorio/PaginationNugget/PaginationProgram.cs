﻿using System.Text;
using OutputProgram;
using InputProgram;
namespace PaginationProgram;

//Domain Service
public class Pagination
{
    public Output Result(Input currentPage, Input totalPages)
    {
        Output output;

        if (currentPage.Value == -1 || totalPages.Value == -1)
        {
            output = new Output("Invalid Input");
            return output;
        }
        else
        {
            output = new Output(PaginationProcess(currentPage.Value, totalPages.Value));
            return output;
        }
    }

    private string PaginationProcess(int currentPage, int totalPages)
    {
        StringBuilder pagination = new StringBuilder();

        if (totalPages <= 7)
        {
            for (int i = 1; i <= totalPages; i++)
            {
                if (i == currentPage) { pagination.Append($"({i}) "); }
                else { pagination.Append($"{i} "); }
            }
        }
        else
        {
            if (currentPage == 1)
            {
                pagination.Append($"({currentPage}) ");
                pagination.Append("2 3 4 5 ... ");
                pagination.Append($"{totalPages}");
            }
            else if (currentPage == totalPages)
            {
                pagination.Append("1 ... ");
                pagination.Append($"{totalPages - 4} {totalPages - 3} {totalPages - 2} {totalPages - 1} ");
                pagination.Append($"({totalPages})");
            }
            else if (currentPage <= 4)
            {
                for (int i = 1; i <= 5; i++)
                {
                    if (i == currentPage) { pagination.Append($"({i}) "); }
                    else { pagination.Append($"{i} "); }
                }
                pagination.Append($"... {totalPages}");
            }
            else if (currentPage >= totalPages - 3)
            {
                pagination.Append("1 ... ");
                for (int i = totalPages - 4; i <= totalPages; i++)
                {
                    if (i == currentPage) { pagination.Append($"({i}) "); }
                    else { pagination.Append($"{i} "); }
                }
            }
            else
            {
                pagination.Append($"1 ... {currentPage - 1} ({currentPage}) {currentPage + 1} ... {totalPages}");
            }
        }

        return pagination.ToString().Trim();
    }
}
