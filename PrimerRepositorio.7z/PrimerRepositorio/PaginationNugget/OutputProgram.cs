namespace OutputProgram;

//Entity "Pendiente ID"
public class Output
{
    private dynamic Result {get;}
    private int Id {get;}

    public Output(dynamic result)
    { Result = result; Id = generateId(); }

    static int generateId()
    { int counter = 0; counter = counter++; return counter;}
    
    public dynamic getResult()
    {return Result;}
}