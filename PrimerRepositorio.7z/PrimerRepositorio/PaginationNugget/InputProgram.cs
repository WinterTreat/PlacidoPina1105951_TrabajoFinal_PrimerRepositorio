namespace InputProgram;

//Value Object
public class Input
{
    public int Value {get;}

    private int Validation(int value)
    {
        if(value < 1) {return -1;}
        else {return value;}
    }

    public Input(int value)
    { Value = Validation(value); }
}